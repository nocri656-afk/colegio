CREATE DATABASE IF NOT EXISTS liceo_valle CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE liceo_valle;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  open_id VARCHAR(64) NOT NULL UNIQUE,
  name VARCHAR(160),
  email VARCHAR(320),
  role ENUM('user','admin') NOT NULL DEFAULT 'user'
);
CREATE TABLE IF NOT EXISTS courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  level VARCHAR(80) NOT NULL
);
CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  rut VARCHAR(20) NOT NULL,
  course_id INT NOT NULL,
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
CREATE TABLE IF NOT EXISTS attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  attendance_date DATE NOT NULL,
  status ENUM('presente','ausente','atrasado') NOT NULL,
  UNIQUE KEY student_date (student_id, attendance_date),
  FOREIGN KEY (student_id) REFERENCES students(id)
);
CREATE TABLE IF NOT EXISTS notes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  author_id INT NOT NULL,
  kind ENUM('positiva','negativa') NOT NULL,
  description VARCHAR(500) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id),
  FOREIGN KEY (author_id) REFERENCES users(id)
);

INSERT IGNORE INTO users (open_id, name, email, role) VALUES ('local-demo','Equipo escolar','equipo@liceo.cl','admin');
INSERT IGNORE INTO courses (name, level) VALUES ('1° Medio A','Educación Media'),('8° Básico B','Educación Básica'),('5° Básico A','Educación Básica');
INSERT INTO students (name, rut, course_id)
SELECT 'Martina González','21.345.678-9',id FROM courses WHERE name='1° Medio A' AND NOT EXISTS (SELECT 1 FROM students WHERE rut='21.345.678-9');
INSERT INTO students (name, rut, course_id)
SELECT 'Tomás Rojas','20.987.654-3',id FROM courses WHERE name='1° Medio A' AND NOT EXISTS (SELECT 1 FROM students WHERE rut='20.987.654-3');
INSERT INTO students (name, rut, course_id)
SELECT 'Sofía Martínez','22.111.222-3',id FROM courses WHERE name='8° Básico B' AND NOT EXISTS (SELECT 1 FROM students WHERE rut='22.111.222-3');
INSERT INTO students (name, rut, course_id)
SELECT 'Benjamín Soto','21.444.555-6',id FROM courses WHERE name='8° Básico B' AND NOT EXISTS (SELECT 1 FROM students WHERE rut='21.444.555-6');
INSERT INTO students (name, rut, course_id)
SELECT 'Emilia Pérez','23.777.888-9',id FROM courses WHERE name='5° Básico A' AND NOT EXISTS (SELECT 1 FROM students WHERE rut='23.777.888-9');

INSERT IGNORE INTO attendance (student_id, attendance_date, status) SELECT id,'2026-10-26','ausente' FROM students WHERE rut='21.345.678-9';
INSERT IGNORE INTO attendance (student_id, attendance_date, status) SELECT id,'2026-10-27','ausente' FROM students WHERE rut='21.345.678-9';
INSERT IGNORE INTO attendance (student_id, attendance_date, status) SELECT id,'2026-10-28','ausente' FROM students WHERE rut='21.345.678-9';
INSERT IGNORE INTO attendance (student_id, attendance_date, status) SELECT id,'2026-10-28','atrasado' FROM students WHERE rut='20.987.654-3';
INSERT IGNORE INTO attendance (student_id, attendance_date, status) SELECT id,'2026-10-28','presente' FROM students WHERE rut IN ('22.111.222-3','21.444.555-6','23.777.888-9');
INSERT INTO notes (student_id, author_id, kind, description)
SELECT s.id,u.id,'negativa','No presentó el trabajo de Matemática.' FROM students s, users u WHERE s.rut='21.345.678-9' AND u.open_id='local-demo' AND NOT EXISTS (SELECT 1 FROM notes WHERE description='No presentó el trabajo de Matemática.');
INSERT INTO notes (student_id, author_id, kind, description)
SELECT s.id,u.id,'positiva','Ayudó activamente a su equipo.' FROM students s, users u WHERE s.rut='22.111.222-3' AND u.open_id='local-demo' AND NOT EXISTS (SELECT 1 FROM notes WHERE description='Ayudó activamente a su equipo.');
