<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';
try {
  $courses = $conexion->query('SELECT id, name, level FROM courses ORDER BY name')->fetchAll();
  $students = $conexion->query('SELECT s.id, s.name, s.rut, s.course_id, c.name AS course_name, (SELECT COUNT(*) FROM notes n WHERE n.student_id=s.id) AS notes_count FROM students s JOIN courses c ON c.id=s.course_id ORDER BY c.name, s.name')->fetchAll();
  $attendance = $conexion->query('SELECT student_id, attendance_date, status FROM attendance ORDER BY attendance_date DESC')->fetchAll();
  $notes = $conexion->query('SELECT n.id, n.student_id, s.name AS student_name, n.kind, n.description, n.created_at FROM notes n JOIN students s ON s.id=n.student_id ORDER BY n.created_at DESC')->fetchAll();
  $history = [];
  foreach ($attendance as $row) { $history[$row['student_id']][] = $row; }
  foreach ($students as &$student) {
    $items = $history[$student['id']] ?? [];
    $student['latest_status'] = $items[0]['status'] ?? null;
    $student['consecutive_absences'] = 0;
    foreach ($items as $item) { if ($item['status'] === 'ausente') $student['consecutive_absences']++; else break; }
  }
  echo json_encode(['status'=>'success','courses'=>$courses,'students'=>$students,'notes'=>$notes], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>'Error al consultar: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
?>
