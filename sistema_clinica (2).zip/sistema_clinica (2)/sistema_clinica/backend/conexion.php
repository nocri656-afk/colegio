<?php
$host = 'localhost';
$dbname = 'liceo_valle';
$user = 'root';
$pass = '';
try {
  $conexion = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
} catch (PDOException $e) {
  http_response_code(500);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['status'=>'error','message'=>'No se pudo conectar a la base de datos: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
  exit;
}
?>
