<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';
$input = json_decode(file_get_contents('php://input'), true);
$studentId = (int)($input['student_id'] ?? 0);
$kind = $input['kind'] ?? '';
$description = trim($input['description'] ?? '');
if (!$studentId || !in_array($kind, ['positiva','negativa'], true) || $description === '') { http_response_code(400); echo json_encode(['status'=>'error','message'=>'Completa estudiante, tipo y descripción']); exit; }
try {
  $author = $conexion->query('SELECT id FROM users ORDER BY id LIMIT 1')->fetchColumn();
  if (!$author) { $conexion->exec("INSERT INTO users (open_id, name, email, role) VALUES ('local-demo', 'Equipo escolar', 'local@liceo.cl', 'admin')"); $author = $conexion->lastInsertId(); }
  $stmt = $conexion->prepare('INSERT INTO notes (student_id, author_id, kind, description) VALUES (?, ?, ?, ?)');
  $stmt->execute([$studentId, $author, $kind, $description]);
  echo json_encode(['status'=>'success','message'=>'Anotación guardada']);
} catch (Throwable $e) { http_response_code(500); echo json_encode(['status'=>'error','message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE); }
?>
