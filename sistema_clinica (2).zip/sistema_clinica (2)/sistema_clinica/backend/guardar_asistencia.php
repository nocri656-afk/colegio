<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';
$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['records']) || !is_array($input['records'])) { http_response_code(400); echo json_encode(['status'=>'error','message'=>'No se recibieron registros']); exit; }
try {
  $stmt = $conexion->prepare('INSERT INTO attendance (student_id, attendance_date, status) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status)');
  foreach ($input['records'] as $record) {
    $status = $record['status'] ?? '';
    if (!in_array($status, ['presente','ausente','atrasado'], true)) continue;
    $stmt->execute([(int)$record['student_id'], $record['date'], $status]);
  }
  echo json_encode(['status'=>'success','message'=>'Asistencia guardada']);
} catch (Throwable $e) { http_response_code(500); echo json_encode(['status'=>'error','message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE); }
?>
