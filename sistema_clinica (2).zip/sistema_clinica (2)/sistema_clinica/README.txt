SISTEMA ESCOLAR - LICEO BICENTENARIO DEL VALLE
===============================================

Esta versión usa únicamente:
- HTML para la estructura.
- CSS para el diseño responsivo.
- JavaScript para la interacción y Fetch.
- PHP y MySQL únicamente para guardar y consultar datos.

ESTRUCTURA
----------
index.html                         Página web principal
css/styles.css                     Estilos
js/app.js                          Interacción del frontend
backend/conexion.php               Conexión PHP con MySQL
backend/api.php                    Consulta del dashboard
backend/guardar_asistencia.php     Guarda Presente/Ausente/Atrasado
backend/guardar_anotacion.php      Guarda anotaciones positivas/negativas
liceo_valle.sql                    Base de datos y datos de ejemplo
documento_referencia/              Word del Caso 4

INSTALACIÓN EN XAMPP
--------------------
1. Copia la carpeta sistema_clinica dentro de C:\xampp\htdocs\
2. Activa Apache y MySQL en XAMPP.
3. Entra a http://localhost/phpmyadmin
4. Importa el archivo liceo_valle.sql.
5. Abre http://localhost/sistema_clinica/index.html

NO abras index.html haciendo doble clic. Debes entrar mediante localhost
para que Apache ejecute los archivos PHP.

FUNCIONES
---------
- Resumen para Inspectoría General.
- Registro de asistencia por curso.
- Casilleros Presente, Ausente y Atrasado.
- Alerta automática desde tres ausencias consecutivas.
- Registro de anotaciones positivas y negativas.
- Vista preparada para el portal de apoderados.

Si aparece un error, prueba directamente:
http://localhost/sistema_clinica/backend/api.php

Debe mostrar un JSON con status success. Si aparece Unknown database o
Table doesn't exist, vuelve a importar liceo_valle.sql en phpMyAdmin.
